
const products=[
{name:"Anchor Blue Milk Powder",price:138,tag:"HOT"},
{name:"Anchor Trim Milk Powder",price:138,tag:"HOT"},
{name:"EcoStore Baby Series",price:"From 8.99",tag:"NEW"},
{name:"Bruntwood Lane Wool Soap (12 scents)",price:16.99,tag:"VALUE"},
{name:"Goat Soap Collection",price:8.99,tag:"VALUE"},
{name:"Only Organic Collection",price:"From 8.99",tag:"BABY"},
{name:"G&M Lanolin Cream",price:15.99,tag:"HOT"},
{name:"Lucas Papaw",price:10.99,tag:"HOT"},
{name:"8+ Minutes Mask Collection",price:14.99,tag:"3 TYPES"}
];
