
今晚只要做一次：

1. GitHub → Add file → Upload files
2. 把这个文件夹里的 index.html、admin.html、style.css、products.js、assets 上传覆盖。
3. Commit changes。
4. 30秒后打开：
https://suichunhou-ctrl.github.io/kiwigolden-select-nz/
后台：
https://suichunhou-ctrl.github.io/kiwigolden-select-nz/admin.html
